<?php
declare(strict_types=1);
require_once __DIR__.'/database.php';
require_once __DIR__.'/portal-layout.php';
require_login();
$user=current_user();
function scalar(PDO $pdo,string $sql): int { return (int)$pdo->query($sql)->fetchColumn(); }
$clients=scalar($pdo,"SELECT COUNT(*) FROM clients WHERE active=1");
$cases=scalar($pdo,"SELECT COUNT(*) FROM cases WHERE status NOT IN ('closed','archived')");
$openPay=scalar($pdo,"SELECT COUNT(*) FROM financial_installments WHERE status IN ('open','overdue')");
$tickets=scalar($pdo,"SELECT COUNT(*) FROM tickets WHERE status NOT IN ('closed','resolved')");
portal_start('Visão geral','dashboard');
?>
<div class="topbar"><div><div class="eyebrow">Portal TSP · dados reais</div><h1>Olá, <?=htmlspecialchars($user['name'] ?? 'Administrador')?></h1><div class="lead">Gestão jurídica e relacionamento com clientes em um único ambiente.</div></div><div class="status"><span class="dot"></span> MySQL conectado</div></div>
<section class="stats">
<div class="stat"><span>Clientes ativos</span><strong><?=$clients?></strong></div>
<div class="stat"><span>Processos ativos</span><strong><?=$cases?></strong></div>
<div class="stat"><span>Pagamentos em aberto</span><strong><?=$openPay?></strong></div>
<div class="stat"><span>Chamados abertos</span><strong><?=$tickets?></strong></div>
</section>
<section class="card"><div class="eyebrow">Central TSP</div><h2>Administração do portal</h2><p>Cadastre clientes, crie acessos e acompanhe processos, atualizações, financeiro, chamados e integrações.</p>
<div class="actions"><a class="btn" href="clientes-db.php">Gerenciar clientes</a><a class="btn secondary" href="usuarios-db.php">Usuários e acessos</a></div></section>
<?php portal_end(); ?>
