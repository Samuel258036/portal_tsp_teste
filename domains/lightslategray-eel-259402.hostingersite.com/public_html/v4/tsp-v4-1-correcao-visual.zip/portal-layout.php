<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

function portal_nav(string $active=''): void {
    $user = current_user();
    $role = $user['role'] ?? '';
    $items = [
      ['dashboard.php','Visão geral','dashboard'],
      ['clientes-db.php','Clientes','clientes'],
      ['usuarios-db.php','Usuários e acessos','usuarios'],
      ['processos.php','Processos','processos'],
      ['movimentacoes.php','Atualizações','movimentacoes'],
      ['financeiro.php','Financeiro','financeiro'],
      ['chamados.php','Chamados','chamados'],
      ['integracoes.php','Integrações','integracoes'],
    ];
    echo '<aside class="sidebar"><div class="brand"><small>TSP ADVOGADOS</small><strong>Portal do Cliente</strong></div><nav class="nav">';
    foreach($items as [$href,$label,$key]){
        if (($key==='clientes'||$key==='usuarios'||$key==='integracoes') && !in_array($role,['admin','gestao'],true)) continue;
        echo '<a class="'.($active===$key?'active':'').'" href="'.htmlspecialchars($href).'">'.htmlspecialchars($label).'</a>';
    }
    echo '</nav><div class="side-user"><small>'.htmlspecialchars(role_label($role)).'</small><br><strong>'.htmlspecialchars($user['name'] ?? 'Usuário').'</strong><br><a href="logout.php" style="font-size:12px;color:#c7ad82">Sair</a></div></aside>';
}
function portal_start(string $title, string $active=''): void {
    require_login();
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>'.htmlspecialchars($title).' · TSP</title><link rel="stylesheet" href="assets/portal.css?v=41"></head><body><div class="shell">';
    portal_nav($active);
    echo '<main class="main">';
}
function portal_end(): void { echo '</main></div></body></html>'; }
