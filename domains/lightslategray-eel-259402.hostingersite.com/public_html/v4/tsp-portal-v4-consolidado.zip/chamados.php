<?php
require_once __DIR__.'/auth.php'; require_login(); require_once __DIR__.'/portal-layout.php';
portal_header('Chamados','chamados'); flash(); ?>
<section class="panel"><span class="eyebrow">PORTAL TSP</span><h2>Chamados</h2><p>Central de atendimento do cliente. O módulo será conectado às tabelas tickets e ticket_messages.</p><div class="empty">Módulo preparado para a próxima etapa da integração com MySQL.</div></section>
<?php portal_footer(); ?>