<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__.'/database.php';
if (!empty($_SESSION['user'])) { header('Location: dashboard.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email=trim(strtolower($_POST['email']??''));
    $password=(string)($_POST['password']??'');
    $st=$pdo->prepare("SELECT u.*, c.name client_name FROM users u LEFT JOIN clients c ON c.id=u.client_id WHERE LOWER(u.email)=? AND u.active=1 LIMIT 1");
    $st->execute([$email]); $u=$st->fetch();
    if ($u && password_verify($password, $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role'],'client_id'=>$u['client_id'],'client_name'=>$u['client_name']??null];
        header('Location: dashboard.php'); exit;
    }
    $error='E-mail ou senha inválidos.';
}
?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Portal TSP</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="loginbody"><form method="post" class="loginbox"><span class="eyebrow">TSP ADVOGADOS</span><h1>Portal do Cliente</h1><p>Acesse seu ambiente jurídico.</p><?php if($error):?><div class="alert error"><?=htmlspecialchars($error)?></div><?php endif;?>
<label>E-mail<input type="email" name="email" required autocomplete="username"></label><label>Senha<input type="password" name="password" required autocomplete="current-password"></label><button>Entrar</button></form></body></html>