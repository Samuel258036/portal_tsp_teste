<?php
require_once __DIR__.'/auth.php'; require_login(); require_once __DIR__.'/portal-layout.php';
portal_header('Processos','processos'); flash(); ?>
<section class="panel"><span class="eyebrow">PORTAL TSP</span><h2>Processos</h2><p>Os processos cadastrados no banco aparecerão aqui. A próxima etapa será ligar o formulário de processos à estrutura exata da tabela cases.</p><div class="empty">Módulo preparado para a próxima etapa da integração com MySQL.</div></section>
<?php portal_footer(); ?>