<?php
require_once __DIR__.'/auth.php'; require_admin(); require_once __DIR__.'/portal-layout.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $name=trim($_POST['name']??'');$email=trim(strtolower($_POST['email']??''));$password=(string)($_POST['password']??'');$role=$_POST['role']??'client';$clientId=($role==='admin'?null:(int)($_POST['client_id']??0));
 if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<8||($role==='client'&&!$clientId)){
  $_SESSION['flash']=['type'=>'error','message'=>'Preencha os campos. A senha deve ter pelo menos 8 caracteres e usuário cliente deve estar vinculado a um cliente.'];
 } else {
  try{$st=$pdo->prepare("INSERT INTO users (client_id,name,email,password_hash,role,active,created_at,updated_at) VALUES (?,?,?,?,?,1,NOW(),NOW())");$st->execute([$clientId,$name,$email,password_hash($password,PASSWORD_DEFAULT),$role]);$_SESSION['flash']=['type'=>'ok','message'=>'Acesso criado com sucesso.'];}
  catch(PDOException $e){$_SESSION['flash']=['type'=>'error','message'=>'Não foi possível criar o acesso. Verifique se o e-mail já existe.'];}
 }
 header('Location: usuarios.php');exit;
}
$clients=$pdo->query("SELECT id,name FROM clients WHERE active=1 ORDER BY name")->fetchAll();
$users=$pdo->query("SELECT u.*,c.name client_name FROM users u LEFT JOIN clients c ON c.id=u.client_id ORDER BY u.id DESC")->fetchAll();
portal_header('Usuários e acessos','usuarios');flash();?>
<section class="panel"><span class="eyebrow">ACESSOS</span><h2>Criar novo usuário</h2>
<form method="post" class="formgrid"><label>Nome<input name="name" required></label><label>E-mail<input type="email" name="email" required></label><label>Senha temporária<input type="password" name="password" minlength="8" required></label><label>Perfil<select name="role"><option value="client">Cliente</option><option value="admin">Administrador</option></select></label><label>Vincular ao cliente<select name="client_id"><option value="">Selecione</option><?php foreach($clients as $c):?><option value="<?=$c['id']?>"><?=e($c['name'])?></option><?php endforeach;?></select></label><div><button>Criar acesso</button></div></form></section>
<section class="panel"><h2>Usuários cadastrados</h2><div class="tablewrap"><table><thead><tr><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Cliente</th><th>Status</th></tr></thead><tbody><?php foreach($users as $x):?><tr><td><?=e($x['name'])?></td><td><?=e($x['email'])?></td><td><?=e($x['role'])?></td><td><?=e($x['client_name']??'TSP')?></td><td><span class="badge"><?=$x['active']?'Ativo':'Inativo'?></span></td></tr><?php endforeach;?></tbody></table></div></section>
<?php portal_footer(); ?>