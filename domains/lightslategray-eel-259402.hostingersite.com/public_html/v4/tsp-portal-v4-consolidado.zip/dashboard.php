<?php
require_once __DIR__.'/auth.php'; require_login(); require_once __DIR__.'/portal-layout.php';
$u=current_user(); $admin=($u['role']==='admin'); $cid=(int)($u['client_id']??0);
function cnt(PDO $pdo,string $sql,array $p=[]): int { $s=$pdo->prepare($sql);$s->execute($p);return (int)$s->fetchColumn(); }
if($admin){
 $clients=cnt($pdo,"SELECT COUNT(*) FROM clients WHERE active=1");
 $cases=cnt($pdo,"SELECT COUNT(*) FROM cases");
 $tickets=cnt($pdo,"SELECT COUNT(*) FROM tickets WHERE status NOT IN ('closed','resolved')");
 $payments=cnt($pdo,"SELECT COUNT(*) FROM financial_installments WHERE status NOT IN ('paid','cancelled')");
}else{
 $clients=1;
 $cases=cnt($pdo,"SELECT COUNT(*) FROM cases WHERE client_id=?",[$cid]);
 $tickets=cnt($pdo,"SELECT COUNT(*) FROM tickets WHERE client_id=? AND status NOT IN ('closed','resolved')",[$cid]);
 $payments=cnt($pdo,"SELECT COUNT(*) FROM financial_installments fi JOIN financial_contracts fc ON fc.id=fi.contract_id WHERE fc.client_id=? AND fi.status NOT IN ('paid','cancelled')",[$cid]);
}
portal_header($admin?'Olá, '.($u['name']??'Administrador'):'Olá, '.($u['name']??'Cliente'),'dashboard'); flash(); ?>
<div class="status">● MySQL conectado</div>
<section class="cards"><div class="card"><small>CLIENTES ATIVOS</small><strong><?=$clients?></strong></div><div class="card"><small>PROCESSOS</small><strong><?=$cases?></strong></div><div class="card"><small>PAGAMENTOS EM ABERTO</small><strong><?=$payments?></strong></div><div class="card"><small>CHAMADOS ABERTOS</small><strong><?=$tickets?></strong></div></section>
<section class="panel"><span class="eyebrow">CENTRAL TSP</span><h2><?=$admin?'Administração do portal':'Seu ambiente'?></h2><p><?=$admin?'Cadastre clientes, crie acessos e acompanhe processos, atualizações, financeiro e chamados.':'Acompanhe seus processos, movimentações, financeiro e chamados em um só lugar.'?></p></section>
<?php portal_footer(); ?>

