<?php
require_once __DIR__.'/auth.php'; require_login(); require_once __DIR__.'/portal-layout.php';
portal_header('Integrações','integracoes'); flash(); ?>
<section class="panel"><span class="eyebrow">PORTAL TSP</span><h2>Integrações</h2><p>Gestão de integrações e sincronizações. Nenhum segredo de integração será exibido nesta tela.</p><div class="empty">Módulo preparado para a próxima etapa da integração com MySQL.</div></section>
<?php portal_footer(); ?>