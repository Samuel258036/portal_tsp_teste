TSP PORTAL V4 CONSOLIDADO

1. Faça backup da pasta /public_html/v4 atual.
2. Extraia este ZIP em /public_html/v4 e escolha substituir arquivos existentes.
3. Abra database.php e substitua COLOQUE_SUA_SENHA_AQUI pela senha do usuário MySQL.
4. Não altere o nome do banco nem o usuário, salvo se forem diferentes no seu Hostinger.
5. Acesse /v4/
6. Entre com o administrador já existente no banco.

IMPORTANTE:
- Este pacote usa o banco já criado.
- Clientes são cadastrados pela tela Clientes.
- Usuários são cadastrados pela tela Usuários e acessos.
- Senhas novas usam password_hash/password_verify.
- As telas de processos/financeiro/chamados/integrações foram estabilizadas visualmente e serão conectadas aos campos exatos do banco na próxima etapa.
- Depois de validar tudo, desligue displayErrors no Hostinger.
