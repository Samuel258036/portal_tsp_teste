<?php
require_once __DIR__.'/auth.php'; require_admin(); require_once __DIR__.'/portal-layout.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $name=trim($_POST['name']??''); $doc=trim($_POST['document']??''); $email=trim($_POST['email']??''); $phone=trim($_POST['phone']??'');
 if($name===''){$_SESSION['flash']=['type'=>'error','message'=>'Informe o nome do cliente.'];}
 else{
   $st=$pdo->prepare("INSERT INTO clients (name,document,email,phone,active,created_at,updated_at) VALUES (?,?,?,?,1,NOW(),NOW())");
   $st->execute([$name,$doc?:null,$email?:null,$phone?:null]);
   $_SESSION['flash']=['type'=>'ok','message'=>'Cliente cadastrado com sucesso.'];
 }
 header('Location: clientes.php');exit;
}
$clients=$pdo->query("SELECT * FROM clients ORDER BY id DESC")->fetchAll();
portal_header('Clientes','clientes'); flash(); ?>
<section class="panel"><div class="split"><div><span class="eyebrow">CADASTRO</span><h2>Novo cliente</h2></div></div>
<form method="post" class="formgrid"><label>Nome / Razão social<input name="name" required></label><label>CPF/CNPJ<input name="document"></label><label>E-mail<input type="email" name="email"></label><label>Telefone<input name="phone"></label><div><button>Cadastrar cliente</button></div></form></section>
<section class="panel"><h2>Clientes cadastrados</h2><div class="tablewrap"><table><thead><tr><th>Cliente</th><th>Documento</th><th>E-mail</th><th>Status</th></tr></thead><tbody>
<?php foreach($clients as $c):?><tr><td><?=e($c['name'])?></td><td><?=e($c['document']??'—')?></td><td><?=e($c['email']??'—')?></td><td><span class="badge"><?=$c['active']?'Ativo':'Inativo'?></span></td></tr><?php endforeach;?>
<?php if(!$clients):?><tr><td colspan="4">Nenhum cliente cadastrado.</td></tr><?php endif;?></tbody></table></div></section>
<?php portal_footer(); ?>