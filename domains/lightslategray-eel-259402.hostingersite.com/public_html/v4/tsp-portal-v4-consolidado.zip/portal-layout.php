<?php
declare(strict_types=1);
function e(?string $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function portal_header(string $title, string $active=''): void {
    $u = current_user();
    $items = [
        'dashboard'=>'Visão geral','clientes'=>'Clientes','usuarios'=>'Usuários e acessos',
        'processos'=>'Processos','movimentacoes'=>'Atualizações','financeiro'=>'Financeiro',
        'chamados'=>'Chamados','integracoes'=>'Integrações'
    ];
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>'.e($title).' · TSP Portal</title><link rel="stylesheet" href="assets/style.css"></head><body>';
    echo '<div class="app"><aside class="sidebar"><div class="brand"><div class="brandmark">T</div><div><b>TSP</b><small>SOCIEDADE DE ADVOGADOS</small></div></div>';
    echo '<div class="role">'.(($u['role']??'')==='admin'?'ADMIN':'CLIENTE').'</div><nav>';
    foreach($items as $key=>$label){
        $href = match($key) {
            'dashboard'=>'dashboard.php','clientes'=>'clientes.php','usuarios'=>'usuarios.php',
            'processos'=>'processos.php','movimentacoes'=>'movimentacoes.php','financeiro'=>'financeiro.php',
            'chamados'=>'chamados.php','integracoes'=>'integracoes.php'
        };
        echo '<a class="'.($active===$key?'active':'').'" href="'.$href.'">'.e($label).'</a>';
    }
    echo '</nav><a class="logout" href="logout.php">Sair</a></aside><main class="content">';
    echo '<header class="top"><div><span class="eyebrow">PORTAL TSP</span><h1>'.e($title).'</h1></div><div class="user">'.e($u['name']??'Usuário').'</div></header>';
}
function portal_footer(): void { echo '</main></div></body></html>'; }
function flash(): void {
    if (!empty($_SESSION['flash'])) {
        $f=$_SESSION['flash']; unset($_SESSION['flash']);
        echo '<div class="alert '.e($f['type']??'ok').'">'.e($f['message']??'').'</div>';
    }
}
