<?php
require_once __DIR__.'/auth.php'; require_login(); require_once __DIR__.'/portal-layout.php';
portal_header('Financeiro','financeiro'); flash(); ?>
<section class="panel"><span class="eyebrow">PORTAL TSP</span><h2>Financeiro</h2><p>Central financeira conectada ao portal. O cadastro de contratos e parcelas será ativado após validarmos a estrutura atual das tabelas financeiras.</p><div class="empty">Módulo preparado para a próxima etapa da integração com MySQL.</div></section>
<?php portal_footer(); ?>