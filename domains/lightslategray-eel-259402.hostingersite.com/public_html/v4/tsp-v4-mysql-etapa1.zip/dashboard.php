<?php
declare(strict_types=1);
require_once __DIR__ . '/portal-layout.php';
portal_header('Visão geral', 'dashboard');

$u = current_user();

if ($u['role'] === 'cliente') {
    $clientId = (int)($u['client_id'] ?? 0);
    $q = $pdo->prepare("SELECT COUNT(*) FROM cases WHERE client_id=? AND active=1");
    $q->execute([$clientId]); $cases = (int)$q->fetchColumn();

    $q = $pdo->prepare("SELECT COUNT(*) FROM financial_installments WHERE client_id=? AND status='open'");
    $q->execute([$clientId]); $open = (int)$q->fetchColumn();

    $q = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE client_id=? AND status NOT IN ('resolved','closed')");
    $q->execute([$clientId]); $tickets = (int)$q->fetchColumn();

    $clients = 1;
} else {
    $clients = (int)$pdo->query("SELECT COUNT(*) FROM clients WHERE status='active'")->fetchColumn();
    $cases = (int)$pdo->query("SELECT COUNT(*) FROM cases WHERE active=1")->fetchColumn();
    $open = (int)$pdo->query("SELECT COUNT(*) FROM financial_installments WHERE status='open'")->fetchColumn();
    $tickets = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status NOT IN ('resolved','closed')")->fetchColumn();
}
?>
<header class="pagehead"><div><span class="kicker">PORTAL TSP · DADOS REAIS</span><h1>Olá, <?=e(explode(' ', $u['name'])[0])?></h1><p>O acesso agora está autenticado pelo MySQL do Portal TSP.</p></div></header>
<div class="stats">
<section class="stat"><small>CLIENTES ATIVOS</small><b><?=$clients?></b></section>
<section class="stat"><small>PROCESSOS ATIVOS</small><b><?=$cases?></b></section>
<section class="stat"><small>PAGAMENTOS EM ABERTO</small><b><?=$open?></b></section>
<section class="stat"><small>CHAMADOS ABERTOS</small><b><?=$tickets?></b></section>
</div>
<section class="card"><span class="kicker">ETAPA 1 DA MIGRAÇÃO</span><h2>Login, clientes e usuários já usam o banco real</h2><p>Os demais módulos continuam disponíveis pela V4 e serão migrados para o MySQL nas próximas etapas.</p></section>
<?php portal_footer(); ?>
