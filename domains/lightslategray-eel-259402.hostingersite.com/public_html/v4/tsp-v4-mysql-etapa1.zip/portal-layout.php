<?php
require_once __DIR__ . '/auth.php';

function portal_header(string $title, string $active = ''): void {
    require_login();
    $u = current_user();
    $admin = $u['role'] === 'admin';
    ?>
<!doctype html><html lang="pt-BR"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?=e($title)?> | TSP Portal</title>
<link rel="stylesheet" href="assets/style.css">
<style>
.top-db{display:flex;align-items:center;gap:10px}.db-dot{width:8px;height:8px;border-radius:50%;background:#318b59}
.admin-table{width:100%;border-collapse:collapse}.admin-table th,.admin-table td{text-align:left;padding:14px 10px;border-bottom:1px solid #eee;font-size:13px}.admin-table th{font-size:10px;letter-spacing:1px;color:#777}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.form-grid .full{grid-column:1/-1}.form-grid input,.form-grid select,.form-grid textarea{box-sizing:border-box;width:100%;padding:12px;border:1px solid #ddd;border-radius:10px;background:#fff}
.form-grid label{font-size:11px;font-weight:700}.panel-actions{display:flex;gap:10px;flex-wrap:wrap}.notice-ok{padding:12px 14px;background:#edf8ef;color:#27733b;border-radius:10px;margin:12px 0}.notice-error{padding:12px 14px;background:#fff0f0;color:#a52b2b;border-radius:10px;margin:12px 0}
@media(max-width:760px){.form-grid{grid-template-columns:1fr}.form-grid .full{grid-column:auto}}
</style></head><body>
<div class="app">
<aside class="sidebar">
<div class="brand"><span>TSP</span><small>PORTAL</small></div>
<nav>
<a class="<?=$active==='dashboard'?'active':''?>" href="dashboard.php">Visão geral</a>
<?php if($admin): ?>
<a class="<?=$active==='clientes'?'active':''?>" href="clientes-db.php">Clientes</a>
<a class="<?=$active==='usuarios'?'active':''?>" href="usuarios-db.php">Usuários e acessos</a>
<?php endif; ?>
<a href="processos.php">Processos</a>
<a href="movimentacoes.php">Atualizações</a>
<a href="financeiro.php">Financeiro</a>
<a href="chamados.php">Chamados</a>
<?php if($admin): ?><a href="integracoes.php">Integrações</a><?php endif; ?>
</nav>
<div class="sidebar-foot"><small><?=e(role_label($u['role']))?></small><b><?=e($u['name'])?></b><a href="logout.php">Sair</a></div>
</aside>
<main class="main">
<div class="topbar"><div class="top-db"><span class="db-dot"></span><small>MySQL conectado</small></div><div><b><?=e($u['name'])?></b></div></div>
<?php
}

function portal_footer(): void {
    echo '</main></div></body></html>';
}
