<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/database.php';

function e(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function require_login(): void {
    if (!current_user()) {
        header('Location: index.php');
        exit;
    }
}

function require_roles(array $roles): void {
    require_login();
    if (!in_array(current_user()['role'], $roles, true)) {
        http_response_code(403);
        exit('Acesso não autorizado.');
    }
}

function role_label(string $role): string {
    return [
        'admin' => 'Admin',
        'gestao' => 'Gestão TSP',
        'adv' => 'Adv TSP',
        'cliente' => 'Cliente',
    ][$role] ?? $role;
}

function audit(PDO $pdo, string $action, ?string $entityType = null, ?int $entityId = null, ?string $description = null): void {
    $user = current_user();
    $stmt = $pdo->prepare(
        "INSERT INTO audit_logs (user_id, action, entity_type, entity_id, description, ip_address, user_agent)
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([
        $user['id'] ?? null,
        $action,
        $entityType,
        $entityId,
        $description,
        $_SERVER['REMOTE_ADDR'] ?? null,
        substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500)
    ]);
}
