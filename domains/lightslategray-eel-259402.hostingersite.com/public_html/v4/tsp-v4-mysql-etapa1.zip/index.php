<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

if (current_user()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare(
        "SELECT id, client_id, name, email, password_hash, role, status
         FROM users WHERE email = ? LIMIT 1"
    );
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && $user['status'] === 'active' && password_verify($password, $user['password_hash'])) {
        session_regenerate_id(true);

        $_SESSION['user'] = [
            'id' => (int)$user['id'],
            'client_id' => $user['client_id'] !== null ? (int)$user['client_id'] : null,
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role']
        ];

        $pdo->prepare("UPDATE users SET last_login_at = NOW() WHERE id = ?")->execute([$user['id']]);
        audit($pdo, 'login', 'user', (int)$user['id'], 'Login realizado no Portal TSP');

        header('Location: dashboard.php');
        exit;
    }

    $error = 'E-mail ou senha inválidos.';
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Portal do Cliente | TSP Advogados</title>
<link rel="stylesheet" href="assets/style.css">
<style>
.login-shell{min-height:100vh;display:grid;grid-template-columns:1.05fr .95fr;background:#f5f2ec}
.login-brand{padding:72px;display:flex;flex-direction:column;justify-content:space-between;background:#151b1c;color:#fff}
.login-brand h1{font-family:Georgia,serif;font-size:54px;max-width:620px;margin:18px 0}
.login-brand p{max-width:560px;color:#c8cecb;line-height:1.7}
.login-form-wrap{display:flex;align-items:center;justify-content:center;padding:36px}
.login-card{width:100%;max-width:430px;background:#fff;border-radius:26px;padding:42px;box-shadow:0 25px 70px rgba(0,0,0,.1)}
.login-card h2{font-family:Georgia,serif;font-size:34px;margin:8px 0}
.login-card label{display:block;margin-top:18px;font-size:12px;font-weight:700}
.login-card input{width:100%;box-sizing:border-box;margin-top:7px;padding:14px;border:1px solid #ddd;border-radius:12px}
.login-card button{width:100%;margin-top:22px;padding:15px;border:0;border-radius:12px;background:#1c2222;color:#fff;font-weight:700}
.kicker2{letter-spacing:2px;color:#a98d60;font-size:12px;font-weight:700}.login-error{margin-top:16px;padding:12px;border-radius:10px;background:#fff0f0;color:#9a3030}
@media(max-width:800px){.login-shell{grid-template-columns:1fr}.login-brand{display:none}}
</style>
</head>
<body>
<div class="login-shell">
  <section class="login-brand">
    <div><div class="kicker2">TSP ADVOGADOS</div><h1>Informação jurídica com clareza e proximidade.</h1><p>Acompanhe processos, atualizações, documentos, financeiro e solicitações em um ambiente reservado.</p></div>
    <small>Portal do Cliente · Ambiente de homologação</small>
  </section>
  <section class="login-form-wrap">
    <form method="post" class="login-card">
      <div class="kicker2">ÁREA RESTRITA</div>
      <h2>Bem-vindo</h2>
      <p>Entre com seu acesso ao Portal TSP.</p>
      <?php if($error): ?><div class="login-error"><?=e($error)?></div><?php endif; ?>
      <label>E-mail</label><input type="email" name="email" autocomplete="username" required>
      <label>Senha</label><input type="password" name="password" autocomplete="current-password" required>
      <button type="submit">Entrar no portal</button>
    </form>
  </section>
</div>
</body>
</html>
