<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
if (current_user()) {
    audit($pdo, 'logout', 'user', (int)current_user()['id'], 'Logout realizado no Portal TSP');
}
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
}
session_destroy();
header('Location: index.php');
exit;
