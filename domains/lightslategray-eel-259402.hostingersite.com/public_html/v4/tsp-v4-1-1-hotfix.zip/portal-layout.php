<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

function tsp_role_label(string $role): string {
    return match ($role) {
        'admin' => 'Administrador',
        'gestao' => 'Gestão',
        'advogado' => 'Advogado',
        'cliente' => 'Cliente',
        default => ucfirst($role ?: 'Usuário'),
    };
}

function portal_nav(string $active=''): void {
    $user = current_user();
    $role = (string)($user['role'] ?? '');
    $items = [
      ['dashboard.php','Visão geral','dashboard'],
      ['clientes-db.php','Clientes','clientes'],
      ['usuarios-db.php','Usuários e acessos','usuarios'],
      ['processos.php','Processos','processos'],
      ['movimentacoes.php','Atualizações','movimentacoes'],
      ['financeiro.php','Financeiro','financeiro'],
      ['chamados.php','Chamados','chamados'],
      ['integracoes.php','Integrações','integracoes'],
    ];
    echo '<aside class="sidebar"><div class="brand"><small>TSP ADVOGADOS</small><strong>Portal do Cliente</strong></div><nav class="nav">';
    foreach($items as [$href,$label,$key]){
        if (in_array($key,['clientes','usuarios','integracoes'],true) && !in_array($role,['admin','gestao'],true)) continue;
        echo '<a class="'.($active===$key?'active':'').'" href="'.htmlspecialchars($href,ENT_QUOTES,'UTF-8').'">'.htmlspecialchars($label,ENT_QUOTES,'UTF-8').'</a>';
    }
    echo '</nav><div class="side-user"><small>'.htmlspecialchars(tsp_role_label($role),ENT_QUOTES,'UTF-8').'</small><br><strong>'.htmlspecialchars((string)($user['name'] ?? 'Usuário'),ENT_QUOTES,'UTF-8').'</strong><br><a href="logout.php" style="font-size:12px;color:#c7ad82">Sair</a></div></aside>';
}
function portal_start(string $title, string $active=''): void {
    require_login();
    echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>'.htmlspecialchars($title,ENT_QUOTES,'UTF-8').' · TSP</title><link rel="stylesheet" href="assets/portal.css?v=411"></head><body><div class="shell">';
    portal_nav($active);
    echo '<main class="main">';
}
function portal_end(): void { echo '</main></div></body></html>'; }
