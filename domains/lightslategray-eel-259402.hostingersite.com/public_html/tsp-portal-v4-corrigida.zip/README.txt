TSP PORTAL V4 — CORREÇÃO 1
Correções:
- Atualizações agora selecionam CLIENTE primeiro e depois PROCESSO.
- Compatibilidade com sessão antiga da V3/V4.
- Integrações agora abrem modal de configuração.
- Conectar/desconectar funciona em homologação.
- Teste de sincronização gera log.
- Mantém os 4 perfis e recursos da V4.

IMPORTANTE: não informe credenciais reais. Integrações continuam simuladas até banco/serviço Python real.
