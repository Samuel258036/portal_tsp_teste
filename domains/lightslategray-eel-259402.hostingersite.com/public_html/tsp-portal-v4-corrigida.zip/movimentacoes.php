<?php require_once 'partials.php';allow(['admin','gestao','adv']);
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $a=$_POST['action']??'new';
 if($a==='new'){
  $cid=(int)($_POST['client_id']??0);$caseid=(int)($_POST['case_id']??0);
  if($cid && $caseid){
   $_SESSION['timeline'][]=['id'=>next_id('timeline'),'case_id'=>$caseid,'type'=>$_POST['type'],'title'=>trim($_POST['title']),'text'=>trim($_POST['text']),'internal'=>trim($_POST['internal']),'visible'=>isset($_POST['visible'])?1:0,'action'=>isset($_POST['client_action'])?1:0,'author'=>$_SESSION['user']['name'],'date'=>date('d/m/Y H:i'),'status'=>isset($_POST['visible'])?'Publicado':'Interno'];
   $msg='Atualização salva.';
  }
 }
 if($a==='approve'){foreach($_SESSION['timeline'] as &$t)if($t['id']==(int)$_POST['id']){$t['visible']=1;$t['status']='Publicado';}unset($t);$msg='Movimentação validada e publicada.';}
}
header_page('Atualizações','updates');
$mycases=visible_cases(); $allowedClientIds=array_unique(array_column($mycases,'client_id'));
$clients=array_values(array_filter($_SESSION['clients'],fn($c)=>in_array($c['id'],$allowedClientIds)));?>
<header class="pagehead"><div><span class="kicker">COMUNICAÇÃO PROCESSUAL</span><h1>Atualizações</h1><p>Publique comentários para o cliente, registre notas internas e valide movimentações automáticas.</p></div><button type="button" onclick="updateModal.showModal()">+ Atualizar cliente</button></header>
<?php if($msg):?><div class="success"><?=e($msg)?></div><?php endif;?>
<?php if(!$_SESSION['timeline']):?><section class="card empty"><b>Nenhuma atualização registrada.</b><p>Clique em “Atualizar cliente” para criar a primeira.</p></section><?php endif;?>
<div class="timeline"><?php foreach(array_reverse($_SESSION['timeline']) as $t):$case=null;foreach($mycases as $c)if($c['id']==$t['case_id'])$case=$c;if(!$case)continue;$cl=find_client($case['client_id']);?><article class="timeline-item <?=e($t['type'])?>"><div class="timeline-marker"><?= $t['type']==='judicial'?'⚖':($t['type']==='tsp'?'TSP':'🔒') ?></div><section class="card"><div class="sectionhead"><div><span class="kicker"><?= $t['type']==='judicial'?'MOVIMENTAÇÃO JUDICIAL':($t['type']==='tsp'?'ATUALIZAÇÃO TSP':'NOTA INTERNA') ?></span><h2><?=e($t['title'])?></h2><small><?=e($cl['name']??'')?> · <?=e($case['number'])?> · <?=e($t['date'])?> · <?=e($t['author'])?></small></div><i class="status"><?=e($t['status'])?></i></div><?php if($t['text']):?><p><?=e($t['text'])?></p><?php endif;?><?php if($t['internal']):?><div class="internal"><b>Nota interna</b><p><?=e($t['internal'])?></p></div><?php endif;?><?php if($t['action']):?><div class="client-action">Ação necessária do cliente</div><?php endif;?><?php if($t['status']==='Aguardando validação'):?><form method="post"><input type="hidden" name="action" value="approve"><input type="hidden" name="id" value="<?=$t['id']?>"><button>Validar e publicar</button></form><?php endif;?></section></article><?php endforeach;?></div>
<dialog id="updateModal"><form method="post" class="modal"><input type="hidden" name="action" value="new"><div class="sectionhead"><div><span class="kicker">COMUNICAÇÃO</span><h2>Atualizar cliente</h2></div><button type="button" class="x" onclick="updateModal.close()">×</button></div>
<label>Cliente<select name="client_id" id="clientSelect" required onchange="filterCases()"><option value="">Selecione o cliente</option><?php foreach($clients as $c):?><option value="<?=$c['id']?>"><?=e($c['name'])?></option><?php endforeach;?></select></label>
<label>Processo<select name="case_id" id="caseSelect" required><option value="">Selecione primeiro o cliente</option><?php foreach($mycases as $c):?><option value="<?=$c['id']?>" data-client="<?=$c['client_id']?>" hidden><?=e($c['number'])?> — <?=e($c['title'])?></option><?php endforeach;?></select></label>
<label>Tipo<select name="type" id="typeSelect" onchange="typeChanged()"><option value="tsp">Atualização TSP para o cliente</option><option value="internal">Nota interna — somente TSP</option></select></label>
<label>Título<input name="title" placeholder="Ex.: Acompanhamento do processo" required></label><label>Mensagem para o cliente<textarea name="text" placeholder="Ex.: Seguimos acompanhando. Não houve nova movimentação judicial..."></textarea></label><label>Observação interna<textarea name="internal" placeholder="Somente a equipe TSP verá."></textarea></label><label class="check" id="visibleWrap"><input type="checkbox" name="visible" value="1" checked> Disponibilizar no portal do cliente</label><label class="check"><input type="checkbox" name="client_action" value="1"> Cliente precisa realizar alguma ação</label><button>Publicar atualização</button></form></dialog>
<script>
function filterCases(){let cid=document.getElementById('clientSelect').value,s=document.getElementById('caseSelect');s.value='';[...s.options].forEach((o,i)=>{if(i===0){o.hidden=false;return;}o.hidden=o.dataset.client!==cid;});}
function typeChanged(){let internal=document.getElementById('typeSelect').value==='internal',w=document.getElementById('visibleWrap'),cb=w.querySelector('input');w.style.display=internal?'none':'flex';if(internal)cb.checked=false;}
</script>
<?php footer_page();?>