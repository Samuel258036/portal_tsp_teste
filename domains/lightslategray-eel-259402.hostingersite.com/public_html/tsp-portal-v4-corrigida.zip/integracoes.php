<?php require_once 'partials.php';allow(['admin']);
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $action=$_POST['action']??'';
 if($action==='connect'){
  foreach($_SESSION['integrations'] as &$i)if($i['id']==(int)$_POST['id']){
   $i['status']='Conectada';$i['last']='Conexão configurada';$i['next']='Sincronização disponível';
   $i['endpoint']=trim($_POST['endpoint']??'');$i['account']=trim($_POST['account']??'');
  } unset($i); $msg='Integração configurada em modo de homologação.';
 }
 if($action==='disconnect'){foreach($_SESSION['integrations'] as &$i)if($i['id']==(int)$_POST['id']){$i['status']='Desconectada';}unset($i);$msg='Integração desconectada.';}
 if($action==='sync'){
  $_SESSION['sync_logs'][]=['id'=>next_id('sync_logs'),'source'=>$_POST['source'],'case_id'=>(int)$_POST['case_id'],'date'=>date('d/m/Y H:i'),'result'=>'Sucesso','detail'=>'Teste de sincronização concluído em homologação.'];
  $msg='Teste de sincronização concluído.';
 }
}
header_page('Integrações','integrations');?>
<header class="pagehead"><div><span class="kicker">AUTOMAÇÃO JURÍDICA</span><h1>Integrações</h1><p>Configure as fontes que futuramente alimentarão o Portal TSP pelo serviço Python.</p></div><span class="badge">Homologação</span></header>
<?php if($msg):?><div class="success"><?=e($msg)?></div><?php endif;?>
<div class="integration-grid"><?php foreach($_SESSION['integrations'] as $i):?><section class="card integration"><div class="integration-top"><div class="integration-icon">⌁</div><i class="status"><?=e($i['status'])?></i></div><h2><?=e($i['name'])?></h2><p><?=e($i['type'])?></p><div class="integration-stats"><div><small>STATUS DA CONEXÃO</small><b><?=e($i['status'])?></b></div><div><small>PROCESSOS VINCULADOS</small><b><?=e($i['cases'])?></b></div></div>
<?php if($i['status']==='Conectada'):?><form method="post"><input type="hidden" name="action" value="disconnect"><input type="hidden" name="id" value="<?=$i['id']?>"><button class="ghost">Desconectar</button></form>
<?php else:?><button type="button" class="ghost" onclick="openIntegration(<?=$i['id']?>,'<?=e($i['name'])?>')">Configurar conexão</button><?php endif;?></section><?php endforeach;?></div>
<section class="card"><div class="sectionhead"><div><span class="kicker">CENTRAL DE SINCRONIZAÇÃO</span><h2>Histórico de consultas</h2></div><button type="button" onclick="syncModal.showModal()">Testar sincronização</button></div>
<?php if(!$_SESSION['sync_logs']):?><div class="empty"><b>Nenhuma sincronização executada.</b><p>Configure uma integração e execute um teste.</p></div><?php else:?><div class="table"><div class="tr synchead"><span>Fonte</span><span>Processo</span><span>Data</span><span>Resultado</span><span>Detalhe</span></div><?php foreach(array_reverse($_SESSION['sync_logs']) as $l):$case=null;foreach($_SESSION['cases'] as $c)if($c['id']==$l['case_id'])$case=$c;?><div class="tr syncrow"><span><b><?=e($l['source'])?></b></span><span><?=e($case['number']??'')?></span><span><?=e($l['date'])?></span><span><i class="status"><?=e($l['result'])?></i></span><span><?=e($l['detail'])?></span></div><?php endforeach;?></div><?php endif;?></section>
<section class="card security"><div><span class="kicker">SEGURANÇA</span><h2>Credenciais protegidas</h2><p>Esta tela simula a configuração. Não use tokens reais ainda. Na produção, credenciais ficarão fora do diretório público e não serão exibidas no painel.</p></div><span class="masked">••••••••••••</span></section>
<dialog id="integrationModal"><form method="post" class="modal"><input type="hidden" name="action" value="connect"><input type="hidden" id="integration_id" name="id"><div class="sectionhead"><div><span class="kicker">CONFIGURAÇÃO</span><h2 id="integration_title">Integração</h2></div><button type="button" class="x" onclick="integrationModal.close()">×</button></div><div class="notice">Modo demonstração: não informe uma credencial real nesta etapa.</div><label>Endpoint / URL da API<input name="endpoint" placeholder="Ex.: endpoint fornecido pelo integrador"></label><label>Conta / identificador<input name="account" placeholder="Identificador da conta"></label><label>Token de teste<input type="password" name="token" placeholder="••••••••••••"></label><button>Salvar e conectar</button></form></dialog>
<dialog id="syncModal"><form method="post" class="modal"><input type="hidden" name="action" value="sync"><div class="sectionhead"><h2>Teste de sincronização</h2><button type="button" class="x" onclick="syncModal.close()">×</button></div><label>Fonte<select name="source"><?php foreach($_SESSION['integrations'] as $i):?><option><?=e($i['name'])?></option><?php endforeach;?></select></label><label>Processo<select name="case_id"><?php foreach($_SESSION['cases'] as $c):?><option value="<?=$c['id']?>"><?=e($c['number'])?> — <?=e($c['title'])?></option><?php endforeach;?></select></label><button>Executar teste</button></form></dialog>
<script>function openIntegration(id,name){document.getElementById('integration_id').value=id;document.getElementById('integration_title').textContent=name;document.getElementById('integrationModal').showModal();}</script>
<?php footer_page();?>